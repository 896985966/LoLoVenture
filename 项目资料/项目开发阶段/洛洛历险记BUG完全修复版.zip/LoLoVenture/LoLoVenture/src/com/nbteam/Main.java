package com.nbteam;

import static com.nbteam.LoLoVenture.*;

public class Main {
    public static void main(String[] args) {
        menuView();
    }
}
