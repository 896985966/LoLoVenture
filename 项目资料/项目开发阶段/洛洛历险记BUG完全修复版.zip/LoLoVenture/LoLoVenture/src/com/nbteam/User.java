package com.nbteam;

public class User {
    // 用户id
    public  String id;
    //用户密码
    public  String password;
    //用户最高分数记录
    public int maxScore;
}
